package ua.edu.krnu.javatech.examples.counter;

public interface Counter {
    void increment();
    int getValue();
}