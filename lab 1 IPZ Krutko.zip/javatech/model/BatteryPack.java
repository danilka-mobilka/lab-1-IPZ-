package ua.edu.krnu.javatech.model;

public class BatteryPack {
    private final Long id;
    private final String serialNumber;
    private final String chemistry;
    private final double nominalVoltage;
    private final double capacityAh;
    private final int chargePercent;
    private final BatteryStatus status;
    private final String location;

    public BatteryPack(Long id,
                       String serialNumber,
                       String chemistry,
                       double nominalVoltage,
                       double capacityAh,
                       int chargePercent,
                       BatteryStatus status,
                       String location) {
        this.id = id;
        this.serialNumber = serialNumber;
        this.chemistry = chemistry;
        this.nominalVoltage = nominalVoltage;
        this.capacityAh = capacityAh;
        this.chargePercent = chargePercent;
        this.status = status;
        this.location = location;
    }

    public Long getId() { return id; }
    public String getSerialNumber() { return serialNumber; }
    public String getChemistry() { return chemistry; }
    public double getNominalVoltage() { return nominalVoltage; }
    public double getCapacityAh() { return capacityAh; }
    public int getChargePercent() { return chargePercent; }
    public BatteryStatus getStatus() { return status; }
    public String getLocation() { return location; }

    @Override
    public String toString() {
        return "BatteryPack{" +
                "id=" + id +
                ", serialNumber='" + serialNumber + '\'' +
                ", chemistry='" + chemistry + '\'' +
                ", nominalVoltage=" + nominalVoltage +
                ", capacityAh=" + capacityAh +
                ", chargePercent=" + chargePercent +
                ", status=" + status +
                ", location='" + location + '\'' +
                '}';
    }
}