package ua.edu.krnu.javatech.model;

public enum BatteryStatus {
    NORMAL,
    LOW_CHARGE,
    CHARGING,
    FAULT,
    MAINTENANCE
}