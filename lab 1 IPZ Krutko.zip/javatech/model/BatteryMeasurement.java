package ua.edu.krnu.javatech.model;

import java.time.LocalDateTime;

public record BatteryMeasurement(
        Long id,
        Long batteryPackId,
        LocalDateTime measuredAt,
        double voltage,
        double current,
        double temperatureC,
        int stateOfChargePercent
) {
}