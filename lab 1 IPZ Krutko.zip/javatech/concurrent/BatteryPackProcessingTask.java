package ua.edu.krnu.javatech.concurrent;

import ua.edu.krnu.javatech.model.BatteryPack;
import ua.edu.krnu.javatech.model.ProcessingResult;

import java.util.concurrent.Callable;

public class BatteryPackProcessingTask implements Callable<ProcessingResult> {
    private final BatteryPack batteryPack;

    public BatteryPackProcessingTask(BatteryPack batteryPack) {
        this.batteryPack = batteryPack;
    }

    @Override
    public ProcessingResult call() throws InterruptedException {
        long delayMs = 100 + (batteryPack.getId() % 5) * 50;
        Thread.sleep(delayMs); // імітація блокуючого I/O

        Thread current = Thread.currentThread();

        boolean success = batteryPack.getSerialNumber() != null
                && !batteryPack.getSerialNumber().isBlank()
                && batteryPack.getNominalVoltage() > 0
                && batteryPack.getCapacityAh() > 0
                && batteryPack.getChargePercent() >= 0
                && batteryPack.getChargePercent() <= 100;

        return new ProcessingResult(
                batteryPack.getId(),
                batteryPack.getSerialNumber(),
                success,
                current.threadId(),
                current.isVirtual(),
                delayMs
        );
    }
}