package ua.edu.krnu.javatech.app;

import ua.edu.krnu.javatech.model.BatteryPack;
import ua.edu.krnu.javatech.model.BatteryStatus;
import ua.edu.krnu.javatech.model.ProcessingResult;
import ua.edu.krnu.javatech.service.ConcurrentProcessingService;

import java.util.ArrayList;
import java.util.List;

public class Lab01Application {

    public static void main(String[] args) throws Exception {
        List<BatteryPack> batteries = createBatteries(30);
        ConcurrentProcessingService service = new ConcurrentProcessingService();

        measure("Sequential", () -> service.sequential(batteries));
        measure("Fixed pool (4 threads)", () -> service.fixedPool(batteries));
        measure("Virtual threads", () -> service.virtualThreads(batteries));
    }

    private static List<BatteryPack> createBatteries(int count) {
        List<BatteryPack> result = new ArrayList<>();
        BatteryStatus[] statuses = BatteryStatus.values();
        String[] chemistries = {"Li-Ion", "LiFePO4", "NiMH", "Lead-Acid"};

        for (int i = 1; i <= count; i++) {
            result.add(new BatteryPack(
                    (long) i,
                    "BAT-" + i,
                    chemistries[i % chemistries.length],
                    3.7 + (i % 3) * 1.2,
                    10.0 + (i % 10) * 5.0,
                    (i * 7) % 101,
                    statuses[i % statuses.length],
                    "Lab-" + ((i % 5) + 1)
            ));
        }
        return result;
    }

    private static void measure(String mode, Task task) throws Exception {
        long start = System.nanoTime();
        List<ProcessingResult> results = task.run();
        double timeMs = (System.nanoTime() - start) / 1_000_000.0;

        long ok = results.stream().filter(ProcessingResult::success).count();
        long virtual = results.stream().filter(ProcessingResult::virtualThread).count();

        System.out.printf("%n%s: %.2f ms, processed=%d, success=%d, virtual=%d%n",
                mode, timeMs, results.size(), ok, virtual);
    }

    @FunctionalInterface
    private interface Task {
        List<ProcessingResult> run() throws Exception;
    }
}