package ua.edu.krnu.javatech.service;

import ua.edu.krnu.javatech.concurrent.BatteryPackProcessingTask;
import ua.edu.krnu.javatech.model.BatteryPack;
import ua.edu.krnu.javatech.model.ProcessingResult;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

public class ConcurrentProcessingService {

    public List<ProcessingResult> sequential(List<BatteryPack> batteries) throws Exception {
        List<ProcessingResult> results = new ArrayList<>();
        for (BatteryPack battery : batteries) {
            results.add(new BatteryPackProcessingTask(battery).call());
        }
        return results;
    }

    public List<ProcessingResult> fixedPool(List<BatteryPack> batteries) throws Exception {
        try (ExecutorService executor = Executors.newFixedThreadPool(4)) {
            return execute(batteries, executor);
        }
    }

    public List<ProcessingResult> virtualThreads(List<BatteryPack> batteries) throws Exception {
        try (ExecutorService executor = Executors.newVirtualThreadPerTaskExecutor()) {
            return execute(batteries, executor);
        }
    }

    private List<ProcessingResult> execute(List<BatteryPack> batteries,
                                           ExecutorService executor) throws Exception {
        List<Future<ProcessingResult>> futures = new ArrayList<>();

        for (BatteryPack battery : batteries) {
            futures.add(executor.submit(new BatteryPackProcessingTask(battery)));
        }

        List<ProcessingResult> results = new ArrayList<>();
        for (Future<ProcessingResult> future : futures) {
            results.add(future.get());
        }
        return results;
    }
}